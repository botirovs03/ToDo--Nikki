const mysql = require('mysql2');
const knex = require('knex');

// Define your database connection configuration in a single object
const dbConfig = {
  host: '83.69.139.151',
  user: 'jduuz_Saydiakhror',
  password: '49kgUB3UgQLF7.w',
  database: 'jduuz_cowork'
};

// Create a MySQL connection using mysql2
const connection = mysql.createConnection(dbConfig);

// Create a knex instance using the same connection configuration
// const knexInstance = knex({
//   client: 'mysql2',
//   connection: dbConfig, // Use the same object here
// });



connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database: ' + err.stack);
    return;
  }
  console.log('Connected to the database as id ' + connection.threadId);
});

module.exports = { connection, dbConfig };
